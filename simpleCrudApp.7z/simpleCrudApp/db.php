<?php
// database class contains your App's Bussiness Logic.
class Database {
 	public $error;
 	public $fnm;
 	public $phn;
 	public $eml;
 	public $adr;
 	public $msg;
 	public $user;
 	public $pass;
 	public	$con = null;

 	public function __construct(){

 		$this->con= mysqli_connect("localhost","root","","bootcamp");
 				if(!$this->con){
 					die("cannot connect to database".mysqli_error());
 					
 						}
 						}

//This Method Inserts record into the database
 	function insert_contact($tablename,$fields){

 		$sql = null;
 			$sql.="INSERT INTO ". $tablename;
 				$sql .= "(".implode(",", array_keys($fields)).") VALUES";
 					$sql .="('".implode("','", array_values($fields))."')";
 						$query = mysqli_query($this->con,$sql);
 						if($query){
 							return true;
 								}else {
 		die("cannot send record".mysqli_error());
 		}
 	}

//This method reads your inserted record, from database
 	function fetch_contact($tablename){
 		$sql = "SELECT * FROM ".$tablename;
 			$array = array();
 				$query = mysqli_query($this->con,$sql);
 					if($query){
 						while($row = mysqli_fetch_assoc($query)){
 							$array[] = $row;
 								}
 							return $array;
 						}else {
 				die;
 			}
 		}


 	function select_contact($tablename,$where){
 	$sql = null;
 		$condition = null;
 			foreach ($where as $key => $value) {
 				$condition.= $key ."='" . $value. "' AND ";
 					}
 						$condition = rtrim($condition," AND ");
 							$sql .= " SELECT * FROM ".$tablename." WHERE ".$condition;
 								$query = mysqli_query($this->con,$sql);
 							$row = mysqli_fetch_array($query);
 							return $row;
 	}

// This method updates a particular record, by overriding with current defined value(s)
 	function update_contact($tablename,$where,$Array){
 					$sql = null;
 						$condition = null;
 							foreach ($where as $key => $value) {
 								$condition.= $key."='".$value."' AND ";
 									}
 										$condition = rtrim($condition," AND ");
 	
 											foreach ($Array as $key => $value) {
 								$sql.= $key."='".$value."', ";
 								}
 							$sql = rtrim($sql,", ");
 						$sql ="UPDATE ".$tablename." SET ".$sql." WHERE ".$condition;
 					$query = mysqli_query($this->con,$sql);
 				if($query)
 			{
 			return true;
 		}else {
 	die("cannot update contact".mysqli_error());
 	}
 }

// As the method name implies, its simple deletes a record
 	function delete_contact($tablename,$where) {
 						$sql= null;
 							$condition = null;
 								foreach ($where as $key => $value) {
 									$condition.= $key. "='". $value."' AND ";
 										}
 									$condition = rtrim($condition," AND ");
 							$sql .= " DELETE FROM ".$tablename. " WHERE ".$condition;
 						$query = mysqli_query($this->con,$sql);
 					if($query){
 				return $query;
 		}else {
 			die("cannot delete contact".mysqli_error());
 		}
 	}

	public function getError(){
 		  return $this->error;
 	}
 	
 	public function checkFullname(){		
 		      return $this->fnm;
 	}
	public function checkPhone(){		
 		      return $this->phn;
 	}

 	public function checkEmail(){		
 		      return $this->eml;
 	}
 	public function checkAddress(){		
 		      return $this->adr;
 	}
 	public function checkMessage(){		
 		      return $this->msg;
 	}
 	public function checkUsername(){
 		return $this->user;
 	}
 	public function checkPassword(){
 		return $this->pass;
 	}

 	 public function validation($fields){
		$count = null;
 	 		foreach($fields as $key => $value){
 	 			if(empty($value)){
 	 				$count ++;
 	 		if($key == "fullname"){
 	 			$this->fnm = "Username Is Required"."</br>";
 	 		}else if($key == "phoneno"){
 	 			 $this->phn = "Phone Number Is Required";
 	 		}else if($key == "email"){
 	 			 $this->eml = "Email Is Required";
 	 		}else if($key == "address"){
 	 			 $this->adr = "Address Is Required";
 	 		}else if($key == "message"){
 	 			 $this->msg = "Message Is Required";
 	 		}else if($key == "username"){
 	 			 $this->user = "Username Is Required";
 	 		}else if($key == "password"){
 	 			 $this->pass = "Password Is Required";
 	 		}
 	 				}
 	 			}
 	 		if($count == 0){
 	 	return true;
 	 }
 	return false;
 	}

 	 public function user_login($tablename,$field){
 	  			$condition = '';
        			foreach ($field as $key => $value) {
            				$condition .= $key . " = '" . $value . "' AND ";
            					}
            					$condition = rtrim($condition, " AND ");
        							$query = " SELECT * FROM " . $tablename . " WHERE " . $condition;
       							 $result = mysqli_query($this->con, $query);
       					$query2 = mysqli_num_rows($result);
       				if($query2==0) {
      			 $this->error = "Invalid Username Or password";
       		}else {
       	while($check=mysqli_fetch_array($query2)){
       				$user=$check["username"];
       					$pass= $check["password"];
       						}
       					if($username == $user && $password == $pass){
       		header("location: contactform.php");
       		}
       	}
 		}
}

// initializing the object of the class
$obj = new Database();

	if(isset($_POST["submit"])){

 $fields = array(
 "fullname" => $_POST["fullname"],
	 "phoneno" => $_POST["phoneno"],
	 	"email" => $_POST["email"],
	 		"address" => $_POST["address"],
	 			"message" => $_POST["message"]
	 	);
	if(!empty($obj->validation($fields))){
		$obj->insert_contact("contacts",$fields);

?>
<script> 
alert("Contact Created Successfully");
</script>

<?php
}
}
	 if(isset($_POST["edit"])){
	 	$id = $_GET["id"];
		$where = array("id"=>$id);
	$Array = array(
		"fullname" => $_POST["fullname"],
			"phoneno" => $_POST["phoneno"],
				"email" => $_POST["email"],
					"address" => $_POST["address"],
						"message" => $_POST["message"]
	);
		if($obj->update_contact("contacts",$where,$Array)){
			header("location:mycontact.php?msg=Contact Updated Successfully");
}
}

	if(isset($_GET["delete"])){
		$id = $_GET["id"];
			$where = array("id"=>$id);
				if($obj->delete_contact("contacts",$where)){
					header("location:mycontact.php?msg=Contact Deleted Successfully");
		}
	}	 

	if(isset($_POST["login"])){
		$field = array(
			"username"=>$_POST["username"],
				"password"=>$_POST["password"]
					);

	if(!empty($obj->validation($field))){
		session_start();
			$_SESSION["username"] = $_POST["username"];
				$obj->user_login("users",$field);
					
	}

}
   

?>