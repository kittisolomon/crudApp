<?php
require "db.php";
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet"  href="css/custom.css">
<title>ContactForm|Home</title>

</head>
<body>

<h1 class="h1">  Please Update The Form Below... </h1>

<div class="container">
	<div class="col col-6">
	<div class="form-input">
	<?php	
	 if(isset($_GET["update"])){
	 	$id = $_GET["id"];
	 	$where = array("id"=>$id);
	$row =$obj->select_contact("contacts",$where);
	 ?>
	 <form method="POST" >
<label _for=""> Fullname: </label> 
<input type="text" name="fullname" class="input" data-input="cm"  value="<?php echo $row["fullname"]; ?>">
</div>
</div>
<div class="col col-6">
	<div class="form-input">
<label _for=""> Phone Number: </label> 
<input type="text" name="phoneno" class="input" data-input="cm" value="<?php echo $row["phoneno"]; ?>">
</div>
</div>

<div class="col col-6">
	<div class="form-input">
<label _for=""> Email: </label> 
<input type="text" name="email" class="input" data-input="cm" value="<?php echo $row["email"]; ?>">
</div>
</div>

<div class="col col-6">
<div class="form-input">
<label _for=""> Address: </label> 
<input type="text" name="address" class="input" data-input="cm" value="<?php echo $row["address"]; ?>">
</div>
</div>

<div class="col col-6">
	<div class="form-input">
<label _for=""> Message: </label> 
<textarea type="text" name="message" class="input"   cols="6" rows="6" >
<?php echo $row["message"]; ?>
</textarea>
</div>
<div class="form-input">
<input type="submit" name="edit" value="update" class="button">
 </div>
</div>
</div>
</div>
</form>
<?php   } ?>

</body>
</html>