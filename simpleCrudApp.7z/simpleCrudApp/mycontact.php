<?php
require "db.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>MyContact|</title>
	<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"  href="css/bootstrap.css">
<link rel="stylesheet"  href="css/bootstrap.min.css">
<link rel="stylesheet"  href="css/bootstrap-theme.css">
<link rel="stylesheet"  href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/custom.css">
</head>
<body>

<div class="h1">  My Contacts </div>

<div class="container"> 
<div class="table table-condensed table-responsive">

<table class="table table-bordered">
	<thead>
		<tr>
			<th>S/No</th>
			<th>Fullname</th>
			<th>Phone Number</th>
			<th>Email</th>
			<th>Address</th>
			<th>Message</th>
			<th>Update</th>
			<th>Delete</th>
		</tr>
	</thead>
	<?php

	$myrow = $obj->fetch_contact("contacts");
	foreach ($myrow as $row) {
	?>
<tbody>
	<tr>
		<td><?php echo $row['id'];  ?></td>
		<td><?php echo $row['fullname'];  ?></td>
		<td><?php echo $row['phoneno'];  ?></td>
		<td><?php echo $row['email'];  ?></td>
		<td><?php echo $row['address'];  ?></td>
		<td><?php echo $row['message'];  ?></td>
		<td><a href="updateform.php?update=1&id=<?php echo $row["id"]; ?>"><span class="gylphicon gylphicon-eye-open"><input type="submit" class="btn btn-warning" name="edit" value="Edit"></span></a></td>
		<td > 	
	<a href="db.php?delete=1&id=<?php echo $row["id"]; ?>" class="btn btn-danger"> Delete </a>
		</td>
		
	</tr>
	<?php } ?>
	<tr>
		
	</tr>
</tbody>
</table>

</div> 

</div>

<script src="js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/npm.js"></script>
</body>
</html>