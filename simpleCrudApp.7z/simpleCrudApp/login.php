<?php

require_once "db.php";

?>

<!DOCTYPE html>
<html>
<head>
<title>simpleCrud|Login</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"  href="css/bootstrap.css">
<link rel="stylesheet"  href="css/bootstrap.min.css">
<link rel="stylesheet"  href="css/bootstrap-theme.css">
<link rel="stylesheet"  href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/custom.css">

<style type="text/css">
	.input{
		padding-left:30%; 
	}
	.padheader{
		display: block;
		height: 40px;
		background-color: #800020;
		color: white;
		border-radius: 4px;
		text-decoration: blink;
		text-align: center;
		margin-top:5px;
	}
	.space{
		margin-left:25%;
	}
	.spacee{
		margin-left:5%;
	}
</style>
</head>
<body>

<form method="POST">
<div class="container">
	<div class="padheader"><h2>Login Panel</h2></div>

	
	<?php //if(isset($_GET['msg'])){  echo "{$_GET['msg']}"; } ?>
<div class="row">
	<div class="col-md-10 ">
		<div class="input">
			<?php
					$kit = $obj->getError();	
						echo "<span class='space alert-danger'>".$kit."</span>";	 
					 ?>
				</div>
					</div>
			<div class="col-md-10">
				<div class="form-group input">
					
				<label _for="">Username</label>	
				<?php
					$sol = $obj->checkUsername();
						echo "<span class=' alert-danger'>".$sol."</span>";
							?>
						<input type="text" name="username" class="form-control" placeholder="Enter Username">
								</div>
									</div>
		<div class="col-md-10">
			<div class="form-group input">
				
				<label _for="">Password</label>
				<?php
					$soz = $obj->checkPassword();
						echo "<span class=' alert-danger'>".$soz."</span>";
							?>	
					<input type="password" name="password" class="form-control" placeholder="Enter Password">
						</div>
					</div>
			<div class="col-md-10" >
				<div class="form-group input">
			 	<input type="submit" name="login" class="button" value="LOgin"> 
			  		</div></div>
</div>
</div>
</form>
<script src="js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/npm.js"></script>
</body>
</html>