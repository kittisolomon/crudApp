<?php
require "db.php";
?>
<!DOCTYPE html>
<html>
<head>
<title>ContactForm|Home</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"  href="css/bootstrap.css">
<link rel="stylesheet"  href="css/bootstrap.min.css">
<link rel="stylesheet"  href="css/bootstrap-theme.css">
<link rel="stylesheet"  href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/custom.css">

</head>
<body>

<h1 class="h1">  Please Fill The Form Below... </h1>
<form method="POST" >
<div class="container">
 
	<div class="col col-6">
	<div class="form-input">
		<?php
		$full = $obj->checkFullname();
		echo "<span class='spacee alert-danger'>". $full."</span>";
		?>
<label _for=""> Fullname: </label>

<input type="text" name="fullname" class="input" data-input="cm" placeholder="Full Name">
</div>
</div>

<div class="col col-6">
	<div class="form-input">
<?php 
	$phone = $obj->checkPhone();
	echo "<span class='spacee alert-danger'>".$phone."</span>";
 ?> 
<label _for=""> Phone Number: </label>

<input type="text" name="phoneno" class="input" data-input="cm" placeholder="Enter phone Number">
</div>
</div>

<div class="col col-6">

<label _for=""> Email: </label> 
<?php 
	$mail = $obj->checkEmail();
	echo "<span class='spacee alert-danger'>".$mail."</span>";
 ?>
<div class="input-group ">
<span class="input-group-addon">@</span>
<input type="text" name="email" class="form-control" data-input="cm" placeholder="Enter Email">
</div>
</div>

<div class="col col-6">
<div class="form-input">
<?php 
	$addr = $obj->checkAddress();
	echo "<span class='spacee alert-danger'>". $addr."</span>";
 ?>	
<label _for=""> Address: </label> 
	
<input type="text" name="address" class="input" data-input="cm" placeholder="Enter Address">
</div>
</div>

<div class="col col-6">
	<div class="form-input">
<?php 
	$messg = $obj->checkMessage();
	echo "<span class='spacee  alert-danger'>".$messg ."</span>";
 ?> 	
<label _for=""> Message: </label>

<textarea name="message" class="input" id=""placeholder="Write Your Message Here...." cols="6" rows="6">
</textarea>
</div>
<div class="form-input">
<input type="submit" name="submit" value="Send Message" class="button">
 </div>
</div>
</div></form>

</div>

<script src="js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/npm.js"></script>
</body>
</html>